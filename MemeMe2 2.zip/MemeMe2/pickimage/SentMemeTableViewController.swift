//
//  SentMemeTableViewController.swift
//  pickimage
//
//  Created by amal alghamdi on 29/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import Foundation
class SentMemeTableViewController : UITableViewController
{
    
    @IBOutlet weak var addMeme: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
       
    }
    
    var memes: [Meme]! {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.memes
}

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return memes.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath) as! TableViewCell
        
        let meme = memes[indexPath.item]
        cell.imageCell.image = meme.memedImage
        cell.labelCell.text = meme.topText + ".." + meme.bottomText
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return view.frame.size.height / 8.0
    }
    

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let viewDetails = DetailViewController()
        viewDetails.imageView.image = memes[indexPath.row].memedImage
        navigationController?.pushViewController(viewDetails, animated: true)
    }
    
}

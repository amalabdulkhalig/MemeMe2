//
//  TableViewCell.swift
//  pickimage
//
//  Created by amal alghamdi on 01/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//
import UIKit
import Foundation

class TableViewCell : UITableViewCell {
    
    @IBOutlet weak var imageCell: UIImageView!
    @IBOutlet weak var labelCell: UILabel!
        
}

//
//  CollectionViewCell.swift
//  pickimage
//
//  Created by amal alghamdi on 01/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
import UIKit

class CollectionViewCell :  UICollectionViewCell
{
    
    @IBOutlet weak var ImageCell: UIImageView!
}

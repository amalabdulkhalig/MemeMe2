//
//  memeDetailsViewController.swift
//  pickimage
//
//  Created by amal alghamdi on 03/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
import UIKit

class DetailViewController:  UIViewController
{
    
    
    @IBOutlet weak var editMeme: UIBarButtonItem!
    
    var imageView = UIImageView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
    }
    
    var memes: [Meme]! {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.memes
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tabBarController?.tabBar.isHidden = true
        view.addSubview(imageView)
        imageView.frame = view.frame
        imageView.contentMode = .scaleAspectFit
    }
    
    
    @IBAction func EditThisMeme(_ sender: Any) {
      
        performSegue(withIdentifier: "editmeme", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "editmeme"
        {
        let vc = segue.destination as! ImagePickerViewController
            
         
        }
    }
    
}

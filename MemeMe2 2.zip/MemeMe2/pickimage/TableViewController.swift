//
//  TableViewController.swift
//  pickimage
//
//  Created by amal alghamdi on 28/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//
import UIKit
import Foundation

class SentMemeTableViewController : UIViewController
{
    var memes: [Meme]! {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.memes
    }
    
}

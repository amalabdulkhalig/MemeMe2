//
//  Meme.swift
//  pickimage
//
//  Created by amal alghamdi on 18/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//



import Foundation
import UIKit

struct Meme {
    var topText: String
    var bottomText: String
    var originalImage: UIImage
    var memedImage: UIImage
}

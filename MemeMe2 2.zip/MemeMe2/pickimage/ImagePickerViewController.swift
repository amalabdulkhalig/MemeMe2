//
//  ViewController.swift
//  pickimage
//
//  Created by amal alghamdi on 16/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class ImagePickerViewController: UIViewController, UIImagePickerControllerDelegate,
UINavigationControllerDelegate , UITextFieldDelegate
{
//--------------------------
    @IBOutlet weak var toptext: UITextField!
    @IBOutlet weak var buttomtext: UITextField!
    @IBOutlet weak var share: UIBarButtonItem!
    @IBOutlet weak var cancel: UIToolbar!
    @IBOutlet weak var Album: UIBarButtonItem!
    @IBOutlet weak var imagePickerView: UIImageView!
    @IBOutlet weak var camera:UIBarButtonItem!
    @IBOutlet weak var buttomtoolbar: UIToolbar!
//--------------------------
    var currentTextField: UITextField?
    var picker: UIImagePickerController!
//--------------------------
    override func viewDidLoad()
    {
        super.viewDidLoad()
        share.isEnabled = false
        unsubscribeFromKeyboardNotifications()
        picker = UIImagePickerController()
        picker.delegate = self
    }
//--------------------------
    override func viewWillAppear(_ animated: Bool)
    {
        subscribeToKeyboardNotifications()
        super.viewWillAppear(animated)
        camera.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        configureText(textField: toptext, withText: "TOP")
        configureText(textField: buttomtext, withText: "BOTTOM")
    }
//--------------------------
    func configureText(textField: UITextField, withText text: String)
    {
        let memeTextAttributes:[NSAttributedString.Key: Any] = [
            NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeColor.rawValue): UIColor.black,
            NSAttributedString.Key(rawValue: NSAttributedString.Key.foregroundColor.rawValue) : UIColor.white,
            NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue): UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
            NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeWidth.rawValue): -2 ]
        
    
       
        textField.defaultTextAttributes = memeTextAttributes
        textField.text = text
        textField.textAlignment = .center
        textField.delegate = self
    }
//--------------------------
   @IBAction func pickAnImageFromAlbum (_ sender: Any)
   {
      pickImage(from: .photoLibrary)
   }
//--------------------------
    @IBAction func pickAnImageFromCamera (_ sender: Any)
    {
      pickImage(from: .camera)
    }
//--------------------------
    
    func imagePickerController(_ picker:UIImagePickerController,didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        {
         imagePickerView.image = image
         share.isEnabled = true
        }
        picker.dismiss(animated: true, completion: nil)
    }
//--------------------------
   func pickImage(from source: UIImagePickerController.SourceType)
    {
        picker.delegate = self
        picker.sourceType = source
        present(picker, animated: true, completion: nil)
        share.isEnabled = true
    }
//--------------------------
    private func save(_ memedImage: UIImage)
    {
        let meme = Meme(topText: toptext.text!, bottomText:buttomtext.text!,originalImage:imagePickerView.image!, memedImage: memedImage)
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.memes.append(meme)
    }
 //--------------------------
    @IBAction private func share(_ sender: Any)
    {
        let memeImage = generateMemedImage()
        let activity = UIActivityViewController(activityItems: [memeImage], applicationActivities: nil)
        
        activity.completionWithItemsHandler = { (_, completed, _, _) in
            if(completed)
            {
                self.save(memeImage)
                self.dismiss(animated: true, completion: nil)
            }
        }
        present(activity, animated: true)
    }
//--------------------------
    func generateMemedImage() -> UIImage
    {
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return memedImage
    }
//--------------------------
    func subscribeToKeyboardNotifications(){
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
//--------------------------
    func unsubscribeFromKeyboardNotifications(){
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
//--------------------------
    func hideTopBottomBars(_ hide: Bool)
    {
       navigationController?.navigationBar.isHidden = hide
        buttomtoolbar.isHidden = hide
        view.backgroundColor = hide ? .clear : .black
    }
//--------------------------
    @objc func keyboardWillShow(_ notification:Notification)
    {
        let keyboardHeight = getKeyboardHeight(notification)
        let KeyBoardMinHeight = (view.frame.height-keyboardHeight)
       
        if let textField = currentTextField,
            textField.frame.maxY - KeyBoardMinHeight > 0
        {
            view.frame.origin.y = -(textField.frame.maxY - KeyBoardMinHeight)
        }
        
        if buttomtext.isFirstResponder {
            view.frame.origin.y = -getKeyboardHeight(notification)
        }
    }
//--------------------------
    func getKeyboardHeight(_ notification:Notification) -> CGFloat
    {
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
    }
//--------------------------    
    @objc private func keyboardWillHide(_ notification: Notification)
    {
        view.frame.origin.y = 0
    }
//--------------------------
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        currentTextField?.text = " "
        currentTextField = textField
    }
//--------------------------
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return textField.resignFirstResponder()
    }
//---------------------------
    
    @IBAction func cancel(_ sender: Any)
    {
        dismiss(animated: true, completion: nil)
        self.viewDidLoad()
        self.viewWillAppear(true)
        picker.delegate = self

    }
}
